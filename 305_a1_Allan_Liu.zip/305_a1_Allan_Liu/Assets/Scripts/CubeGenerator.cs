/* 
UVic CSC 305, 2019 Spring
Assignment 01
Name:
UVic ID:

This is skeleton code we provided.
Feel free to add any member variables or functions that you need.
Feel free to modify the pre-defined function header or constructor if you need.
Please fill your name and uvic id.
*/

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assignment01
{
    public class CubeGenerator
    {
        string name;
        public CubeGenerator()
        {
            //you can define your cube vertices and indices in the constructor.
            name = "CubeGenerator";
        }

        public Texture2D GenBarycentricVis(int width, int height)
        {
            /*
            implement ray-triangle intersection and 
            visualize the barycentric coordinate on each of the triangles of a cube, 
            with Red, Green and Blue for each coordinate.

            int width - width of the returned texture
            int height - height of the return texture
            return:
                Texture2D - Texture2D object which contains the rendered result
            */
            throw new NotImplementedException();
        }

        public Texture2D GenUVMapping(int width, int height, Texture2D inputTexture)
        {
            /*
            implement UV mapping with the calculated barycentric coordinate in the previous step, 
            and visualize a texture image on each face of the cube.
            (choose any texture you like)
            we have declared textureOnCube as a public variable,
            you can attach texture to it from Unity.
            you can define your cube vertices and indices in this function.

            int width - width of the returned texture
            int height - height of the return texture
            Texture2D inputTexture - the texture you need to sample from
            return:
                Texture2D - Texture2D object which contains the rendered result
            */
            throw new NotImplementedException();
        }

        private bool IntersectTriangle(Vector3 origin,
                                        Vector3 direction,//LightDirection
                                        Vector3 vA,
                                        Vector3 vB,
                                        Vector3 vC,
                                        out float t,
                                        out Vector3 barycentricCoordinate)
        {
            /*
            Vector3 origin - origin point of the ray
            Vector3 direction - the direction of the ray
            vA, vB, vC - 3 vertices of the target triangle
            out float t - distance the ray travelled to hit a point
            out Vector3 barycentricCoordinate - you should know what this is
            return:
                bool - indicating hit or not
            */
            throw new NotImplementedException();


            /*Triangle
            List<Vector3> vertices = new List<Vector3>();
            vertices.Add(new Vector3(-4, -2.8f, 10)); //0
            vertices.Add(new Vector3(-4, 2.8f, 10));  //1
            vertices.Add(new Vector3(0, -2.8f, 9));   //2
            vertices.Add(new Vector3(0, 2.8f, 9));    //3
            vertices.Add(new Vector3(4, -2.8f, 10));  //4
            vertices.Add(new Vector3(4, 2.8f, 10));   //5

            List<int> indices = new List<int>();
            //triangle 1
            indices.Add(0);
            indices.Add(1);
            indices.Add(2);
            //triangle 2
            indices.Add(2);
            indices.Add(1);
            indices.Add(3);
            //triangle 3
            indices.Add(2);
            indices.Add(3);
            indices.Add(5);
            //triangle 4
            indices.Add(2);
            indices.Add(5);
            indices.Add(4);

            //**************************

            origin, Direction
            Vector3 LightDirection = new Vector3();

            for (int i = 0; i < pixel_width; ++i)
            {
                for (int j = 0; j < pixel_height; ++j)
                {
                    float a = vA.x - vB.x;
                    float b = vA.y - vB.y;
                    float c = vA.z - vB.z;

                    float d = vA.x - vC.x;
                    float e = vA.y - vC.y;
                    float f = vA.z - vC.z;

                    float g = LightDirection.x; //RayDirection
                    float h = LightDirection.y;
                    float i = LightDirection.z;

                    float j = vA.x - o_r.x; //[Origin]
                    float k = vA.y - o_r.y;
                    float l = vA.z - o_r.z;
                    
                    //cramer's rule
                    float ei_hf = e * i - h * f;
                    float gf_di = g * f - d * i;

                    float alpha = 1 - beta - gamma
                    barycentric_coordinate = new Vector3(alpha, beta, gamma);

                    float M = a * ei_hf + b * gf_di + c * dh_eg;
                    float beta = //calculate this using formula
                    float gamma =
                    float t =
                    
                    //barycentric
                    if (t > 0)
                    {
                        beta > 0 && gamma > 0 && (beta + gamma) < 1
                    }
                    

            List<Vector2> UVs = new List<Vector2>();
            UVs.Add(new Vector2(0, 0));
            UVs.Add(new Vector2(0, 1));

            texture_on_cube.width
            texture_on_cube.height // will give height of the cube

            pixelColor = texture_on_cube.getPixel(i,j)
            RayTracingResult.SetPixel(i,j, pixelColor)
            */
        }
    }
}
