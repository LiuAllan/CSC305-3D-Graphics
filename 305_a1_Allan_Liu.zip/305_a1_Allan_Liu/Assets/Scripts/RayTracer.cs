﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


// Allan Liu
// V00806981
// CSC 305
public class RayTracer : MonoBehaviour {

    //initialize variables
    public Texture2D texture_on_cube;
    Texture2D RayTracingResult;
    Vector3 LightDirection = new Vector3(1, 1, -0.5f);
    Color LightColor = Color.yellow;
    Vector3 SphereCenter = new Vector3(3, 0, 5);
    float SphereRadius = 3;

    void Start () {

        Camera this_camera = gameObject.GetComponent<Camera>();
        Debug.Assert(this_camera);

        int pixel_width = this_camera.pixelWidth;
        int pixel_height = this_camera.pixelHeight;

        RayTracingResult = new Texture2D(pixel_width, pixel_height);


        
        #region Generate a black and white checker pattern
        
        for (int i = 0; i < pixel_width; ++ i)
            for (int j = 0; j < pixel_height; ++ j)
            {
                int iblock = i / 50;
                int jblock = j / 50;
                RayTracingResult.SetPixel(i, j, 
                    (iblock + jblock) % 2 == 0 ? Color.black : Color.white);
            }
        #endregion
        
        Vector3 ray_origin = Vector3.zero; //new Vector3(0,0,0)
        Vector3 vp_center = Vector3.forward; //new Vector3(0,0,1) [center of view port]
        float vp_width = 3;
        float vp_height = vp_width / pixel_width * pixel_height;

        //half of view port
        float vp_width_half = vp_width / 2;
        float vp_height_half = vp_height / 2;

        //half of pixels
        float pixel_width_half = pixel_width / 2;
        float pixel_height_half = pixel_height / 2;

        //colours
        Color Background = Color.grey;
        Color pixel_colour;
        Color Ambient = new Color(0.1f, 0.1f, 0); //rgba values

        //shading
        float diffuse_str = 0.0008f; //changes "fading" element of the sphere between ambient and light colour
        float specular_str = 0.0007f; //changes brightness top "glow" part of sphere
        float specular_pow = 4f; //changes effect of darker areas

        Vector3 RayDirection = vp_center;

        for (int i = 0; i < pixel_width; ++i)
        {
            for (int j = 0; j < pixel_height; ++j)
            {
                RayDirection.x = (i - pixel_width_half) / pixel_width_half * vp_width_half; //current pixel - half of pixel width / half of pixel width * view port width
                RayDirection.y = (j - pixel_height_half) / pixel_height_half * vp_height_half;

                RayTracingResult.SetPixel(i, j, Color.grey);
                pixel_colour = Background; //set pixel colour the same as background. When pixels intersect the object, change the colour
                RayDirection.Normalize(); //normalize ray direction

                //check intersection with sphere

                //initialize vectors
                Vector3 oc = new Vector3(0,0,0);
                float og;
                float oc_square;
                float og_square;
                float r_square;
                Vector3 p = Vector3.zero;
                Vector3 intersect;

                oc = SphereCenter - ray_origin; //oc and og are vectors
                og = Vector3.Dot(oc, RayDirection);
                oc_square = Vector3.Dot(oc, oc);
                og_square = og * og;
                r_square = SphereRadius * SphereRadius; //Radius squared

                //less than 0->imaginary number; 
                //exactly 0->intersects exactly 1 point; 
                //greater than 0->intersect exactly 2 points
                float discriminent = r_square - (oc_square - og_square);
                if (discriminent >= 0)
                {

                    float d = Mathf.Sqrt(discriminent);
                    float t = og - d;
                    p = ray_origin + RayDirection * t; //ray equation, p == current point
                    intersect = p - SphereCenter;


                    //Shading

                    //Ambient
                    pixel_colour = Ambient;
                    //pixel_colour += LightColor * Ambient;

                    //Diffuse
                    //Vector3 normal = new Vector3(1, 2, 2);
                    float diffuse = Vector3.Dot(intersect, LightDirection) * diffuse_str;
                    //pixel_colour = Ambient * LightColor * diffuse;  
                    pixel_colour += LightColor * diffuse;

                    //Specular
                    Vector3 view = RayDirection * (-1);
                    Vector3 half = view + LightDirection;
                    float blinn = Vector3.Dot(half, intersect);
                    float specular = Mathf.Pow(blinn, specular_pow) * specular_str;

                    pixel_colour += LightColor * specular;

                    RayTracingResult.SetPixel(i, j, pixel_colour);
                }

                //else
                //{
                //    intersect = Vector3.zero;
                //}

            }
        }

        RayTracingResult.Apply();
       
       
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        //Show the generated ray tracing image on screen
        Graphics.Blit(RayTracingResult, destination);
    }
}
