﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

//Allan Liu
//V00806981
//CSC 305

public class TextureCube : MonoBehaviour
{

    //initialize variables
    public Texture2D texture_on_cube;
    Texture2D RayTracingResult;

    void Start()
    {
        Camera this_camera = gameObject.GetComponent<Camera>();
        Debug.Assert(this_camera);

        int pixel_width = this_camera.pixelWidth;
        int pixel_height = this_camera.pixelHeight;

        RayTracingResult = new Texture2D(pixel_width, pixel_height);



        #region Generate a black and white checker pattern

        for (int i = 0; i < pixel_width; ++i)
            for (int j = 0; j < pixel_height; ++j)
            {
                int iblock = i / 50;
                int jblock = j / 50;
                RayTracingResult.SetPixel(i, j,
                    (iblock + jblock) % 2 == 0 ? Color.black : Color.white);
            }
        #endregion


        //Please put your own ray tracing code here
        Vector3 ray_origin = Vector3.zero; //new Vector3(0,0,0)
        Vector3 vp_center = Vector3.forward; //new Vector3(0,0,1) [center of view port]
        Vector3 RayDirection = vp_center;
        float vp_width = 3;
        float vp_height = vp_width / pixel_width * pixel_height;


        //triangle initializations
        List<Vector3> vertices = new List<Vector3>();
        vertices.Add(new Vector3(-4, -2.8f, 10)); //0
        vertices.Add(new Vector3(-4, 2.8f, 10));  //1
        vertices.Add(new Vector3(0, -2.8f, 9));   //2
        vertices.Add(new Vector3(0, 2.8f, 9));    //3
        vertices.Add(new Vector3(4, -2.8f, 10));  //4
        vertices.Add(new Vector3(4, 2.8f, 10));   //5

        //We only need 2 vectors because this is the vertices for the 2D image!
        List<Vector2> UVs = new List<Vector2>();
        UVs.Add(new Vector2(0, 0)); //0
        UVs.Add(new Vector2(0, 1)); //1
        UVs.Add(new Vector2(1, 0)); //2
        UVs.Add(new Vector2(1, 1)); //3
        UVs.Add(new Vector2(0, 0)); //4
        UVs.Add(new Vector2(0, 1)); //5

        //triangle indices links vectors together
        List<int> indices = new List<int>();
        //triangle 1
        indices.Add(0);
        indices.Add(1);
        indices.Add(2);
        //triangle 2
        indices.Add(2);
        indices.Add(1);
        indices.Add(3);
        //triangle 3
        indices.Add(2);
        indices.Add(3);
        indices.Add(5);
        //triangle 4
        indices.Add(2);
        indices.Add(5);
        indices.Add(4);

        //half of view port
        float vp_width_half = vp_width / 2;
        float vp_height_half = vp_height / 2;

        //half of pixels
        float pixel_width_half = pixel_width / 2;
        float pixel_height_half = pixel_height / 2;

        //colours
        Color Background = Color.grey;
        Color pixel_colour;


        for (int ii = 0; ii < pixel_width; ++ii)
        {
            for (int jj = 0; jj < pixel_height; ++jj)
            {
                RayDirection.x = (ii - pixel_width_half) / pixel_width_half * vp_width_half; //current pixel - half of pixel width / half of pixel width * view port width
                RayDirection.y = (jj - pixel_height_half) / pixel_height_half * vp_height_half;

                RayTracingResult.SetPixel(ii, jj, Color.grey);
                pixel_colour = Background; //set pixel colour the same as background. When pixels intersect the object, change the colour
                RayDirection.Normalize(); //normalize ray direction

                //Ray Triangle Intersection
                float a = vertices[0].x - vertices[1].x; //vA-vB
                float b = vertices[0].y - vertices[1].y;
                float c = vertices[0].z - vertices[1].z;

                float d = vertices[0].x - vertices[2].x; //vA-vC
                float e = vertices[0].y - vertices[2].y;
                float f = vertices[0].z - vertices[2].z;

                float g = RayDirection.x; //RayDirection
                float h = RayDirection.y;
                float i = RayDirection.z;

                float j = vertices[0].x - ray_origin.x; //[Origin]
                float k = vertices[0].y - ray_origin.y;
                float l = vertices[0].z - ray_origin.z;

                //Calculations for triangle
                Vector3 vA_vB = new Vector3(a, b, c);
                Vector3 vA_vC = new Vector3(d, e, f);
                Vector3 N = Vector3.Cross(vA_vB, vA_vC);
                float NdotRayDirection = Vector3.Dot(N, RayDirection);

                //calculate p
                Vector3 vA_o = vertices[0] - ray_origin;
                float t = Vector3.Dot(N, vA_o) / NdotRayDirection;
                //Vector3 p = ray_origin + RayDirection * t;

                //cramer's rule
                float ei_hf = e * i - h * f;
                float gf_di = g * f - d * i;
                float dh_eg = d * h - e * g;
                float ak_jb = a * k - j * b;
                float jc_al = j * c - a * l;
                float bl_kc = b * l - k * c;

                float M = a * ei_hf + b * gf_di + c * dh_eg;
                float beta = (j * (ei_hf) + k * (gf_di) + l * (dh_eg)) / M;
                float gamma = (i * (ak_jb) + h * (jc_al) + g * (bl_kc)) / M;

                float alpha = 1 - beta - gamma;
                Vector3 barycentric_coordinate = new Vector3(alpha, beta, gamma);
                Vector2 value;

                //barycentric
                if (t > 0)
                {
                    if (beta > 0 && gamma > 0 && (beta + gamma) < 1)
                    {
                        //value == texture coordinate of the intersection point. Vector contains float values. If type-cast to int, loses decimals info!
                        value = (alpha * UVs[0]) + (beta * UVs[1]) + (gamma * UVs[2]);

                        //int v = (int)value.x;
                        //int v2 = (int)value.y;
                        //pixel_colour = texture_on_cube.GetPixel(v, v2); //get pixel color at pixel location of image ** GetPixel returns an int

                        //int N_width = texture_on_cube.width;
                        //int H_height = texture_on_cube.height;

                        //value.x and value.y == the height and width coordinates of pixel of the cat image
                        //convert coordinates to Colour
                        pixel_colour = texture_on_cube.GetPixelBilinear(value.x, value.y); //get pixel color at pixel location of image

                        RayTracingResult.SetPixel(ii, jj, pixel_colour);
                    }
                }
            }
        }
        //Repeat process for other triangles
        for (int ii = 0; ii < pixel_width; ++ii)
        {
            for (int jj = 0; jj < pixel_height; ++jj)
            {
                RayDirection.x = (ii - pixel_width_half) / pixel_width_half * vp_width_half; //current pixel - half of pixel width / half of pixel width * view port width
                RayDirection.y = (jj - pixel_height_half) / pixel_height_half * vp_height_half;

                pixel_colour = Background; //set pixel colour the same as background. When pixels intersect the object, change the colour
                RayDirection.Normalize(); //normalize ray direction

                //Ray Triangle Intersection
                float a = vertices[2].x - vertices[1].x; //vA-vB
                float b = vertices[2].y - vertices[1].y;
                float c = vertices[2].z - vertices[1].z;

                float d = vertices[2].x - vertices[3].x; //vA-vC
                float e = vertices[2].y - vertices[3].y;
                float f = vertices[2].z - vertices[3].z;

                float g = RayDirection.x; //RayDirection
                float h = RayDirection.y;
                float i = RayDirection.z;

                float j = vertices[2].x - ray_origin.x; //[Origin]
                float k = vertices[2].y - ray_origin.y;
                float l = vertices[2].z - ray_origin.z;

                //Calculations for triangle
                Vector3 vA_vB = new Vector3(a, b, c);
                Vector3 vA_vC = new Vector3(d, e, f);
                Vector3 N = Vector3.Cross(vA_vB, vA_vC);
                float NdotRayDirection = Vector3.Dot(N, RayDirection);

                //calculate p
                Vector3 vA_o = vertices[2] - ray_origin;
                float t = Vector3.Dot(N, vA_o) / NdotRayDirection;
                //Vector3 p = ray_origin + RayDirection * t;

                //cramer's rule
                float ei_hf = e * i - h * f;
                float gf_di = g * f - d * i;
                float dh_eg = d * h - e * g;
                float ak_jb = a * k - j * b;
                float jc_al = j * c - a * l;
                float bl_kc = b * l - k * c;

                float M = a * ei_hf + b * gf_di + c * dh_eg;
                float beta = (j * (ei_hf) + k * (gf_di) + l * (dh_eg)) / M;
                float gamma = (i * (ak_jb) + h * (jc_al) + g * (bl_kc)) / M;

                float alpha = 1 - beta - gamma;
                Vector3 barycentric_coordinate = new Vector3(alpha, beta, gamma);
                Vector2 value;

                //barycentric
                if (t > 0)
                {
                    if (beta > 0 && gamma > 0 && (beta + gamma) < 1)
                    {
                        //value == texture coordinate of the intersection point
                        value = (alpha * UVs[2]) + (beta * UVs[1]) + (gamma * UVs[3]);
                        //int v = (int)value.x;
                        //int v2 = (int)value.y;
                        //pixel_colour = texture_on_cube.GetPixel(v, v2); //get pixel color at pixel location of image

                        //int N_width = texture_on_cube.width;
                        //int H_height = texture_on_cube.height;
                        pixel_colour = texture_on_cube.GetPixelBilinear(value.x, value.y); //get pixel color at pixel location of image

                        RayTracingResult.SetPixel(ii, jj, pixel_colour);
                    }
                }
            }
        }

        for (int ii = 0; ii < pixel_width; ++ii)
        {
            for (int jj = 0; jj < pixel_height; ++jj)
            {
                RayDirection.x = (ii - pixel_width_half) / pixel_width_half * vp_width_half; //current pixel - half of pixel width / half of pixel width * view port width
                RayDirection.y = (jj - pixel_height_half) / pixel_height_half * vp_height_half;

                pixel_colour = Background; //set pixel colour the same as background. When pixels intersect the object, change the colour
                RayDirection.Normalize(); //normalize ray direction

                //Ray Triangle Intersection
                float a = vertices[2].x - vertices[3].x; //vA-vB
                float b = vertices[2].y - vertices[3].y;
                float c = vertices[2].z - vertices[3].z;

                float d = vertices[2].x - vertices[5].x; //vA-vC
                float e = vertices[2].y - vertices[5].y;
                float f = vertices[2].z - vertices[5].z;

                float g = RayDirection.x; //RayDirection
                float h = RayDirection.y;
                float i = RayDirection.z;

                float j = vertices[2].x - ray_origin.x; //[Origin]
                float k = vertices[2].y - ray_origin.y;
                float l = vertices[2].z - ray_origin.z;

                //Calculations for triangle
                Vector3 vA_vB = new Vector3(a, b, c);
                Vector3 vA_vC = new Vector3(d, e, f);
                Vector3 N = Vector3.Cross(vA_vB, vA_vC);
                float NdotRayDirection = Vector3.Dot(N, RayDirection);

                //calculate p
                Vector3 vA_o = vertices[2] - ray_origin;
                float t = Vector3.Dot(N, vA_o) / NdotRayDirection;
                //Vector3 p = ray_origin + RayDirection * t;

                //cramer's rule
                float ei_hf = e * i - h * f;
                float gf_di = g * f - d * i;
                float dh_eg = d * h - e * g;
                float ak_jb = a * k - j * b;
                float jc_al = j * c - a * l;
                float bl_kc = b * l - k * c;

                float M = a * ei_hf + b * gf_di + c * dh_eg;
                float beta = (j * (ei_hf) + k * (gf_di) + l * (dh_eg)) / M;
                float gamma = (i * (ak_jb) + h * (jc_al) + g * (bl_kc)) / M;

                float alpha = 1 - beta - gamma;
                Vector3 barycentric_coordinate = new Vector3(alpha, beta, gamma);
                Vector2 value;

                //barycentric
                if (t > 0)
                {
                    if (beta > 0 && gamma > 0 && (beta + gamma) < 1)
                    {
                        //value == texture coordinate of the intersection point
                        value = (alpha * UVs[2]) + (beta * UVs[3]) + (gamma * UVs[5]);
                        //int v = (int)value.x;
                        //int v2 = (int)value.y;
                        //pixel_colour = texture_on_cube.GetPixel(v, v2); //get pixel color at pixel location of image

                        //int N_width = texture_on_cube.width;
                        //int H_height = texture_on_cube.height;
                        pixel_colour = texture_on_cube.GetPixelBilinear(value.x, value.y); //get pixel color at pixel location of image

                        RayTracingResult.SetPixel(ii, jj, pixel_colour);
                    }
                }
            }
        }

        for (int ii = 0; ii < pixel_width; ++ii)
        {
            for (int jj = 0; jj < pixel_height; ++jj)
            {
                RayDirection.x = (ii - pixel_width_half) / pixel_width_half * vp_width_half; //current pixel - half of pixel width / half of pixel width * view port width
                RayDirection.y = (jj - pixel_height_half) / pixel_height_half * vp_height_half;

                pixel_colour = Background; //set pixel colour the same as background. When pixels intersect the object, change the colour
                RayDirection.Normalize(); //normalize ray direction

                //Ray Triangle Intersection
                float a = vertices[2].x - vertices[5].x; //vA-vB
                float b = vertices[2].y - vertices[5].y;
                float c = vertices[2].z - vertices[5].z;

                float d = vertices[2].x - vertices[4].x; //vA-vC
                float e = vertices[2].y - vertices[4].y;
                float f = vertices[2].z - vertices[4].z;

                float g = RayDirection.x; //RayDirection
                float h = RayDirection.y;
                float i = RayDirection.z;

                float j = vertices[2].x - ray_origin.x; //[Origin]
                float k = vertices[2].y - ray_origin.y;
                float l = vertices[2].z - ray_origin.z;

                //Calculations for triangle
                Vector3 vA_vB = new Vector3(a, b, c);
                Vector3 vA_vC = new Vector3(d, e, f);
                Vector3 N = Vector3.Cross(vA_vB, vA_vC);
                float NdotRayDirection = Vector3.Dot(N, RayDirection);

                //calculate p
                Vector3 vA_o = vertices[2] - ray_origin;
                float t = Vector3.Dot(N, vA_o) / NdotRayDirection;
                //Vector3 p = ray_origin + RayDirection * t;

                //cramer's rule
                float ei_hf = e * i - h * f;
                float gf_di = g * f - d * i;
                float dh_eg = d * h - e * g;
                float ak_jb = a * k - j * b;
                float jc_al = j * c - a * l;
                float bl_kc = b * l - k * c;

                float M = a * ei_hf + b * gf_di + c * dh_eg;
                float beta = (j * (ei_hf) + k * (gf_di) + l * (dh_eg)) / M;
                float gamma = (i * (ak_jb) + h * (jc_al) + g * (bl_kc)) / M;

                float alpha = 1 - beta - gamma;
                Vector3 barycentric_coordinate = new Vector3(alpha, beta, gamma);
                Vector2 value;

                //barycentric
                if (t > 0)
                {
                    if (beta > 0 && gamma > 0 && (beta + gamma) < 1)
                    {
                        //value == texture coordinate of the intersection point
                        value = (alpha * UVs[2]) + (beta * UVs[5]) + (gamma * UVs[4]);
                        //int v = (int)value.x;
                        //int v2 = (int)value.y;
                        //pixel_colour = texture_on_cube.GetPixel(v, v2); //get pixel color at pixel location of image

                        //int N_width = texture_on_cube.width;
                        //int H_height = texture_on_cube.height;
                        pixel_colour = texture_on_cube.GetPixelBilinear(value.x, value.y); //get pixel color at pixel location of image

                        RayTracingResult.SetPixel(ii, jj, pixel_colour);
                    }
                }
            }
        }

        RayTracingResult.Apply();


    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        //Show the generated ray tracing image on screen
        Graphics.Blit(RayTracingResult, destination);
    }
}