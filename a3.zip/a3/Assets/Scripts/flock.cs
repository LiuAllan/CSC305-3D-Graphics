﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class flock : MonoBehaviour {

    public float speed = 20;
    public float rotationSpeed = 20; //how fast the fish will turn
    Vector3 averageHeading; //head towards the average direction of the group
    Vector3 averagePosition; //head towards the average position of the group
    public float neighbourDistance = 10f; //distance the boids will flock. Out of distance = will NOT flock    :3

    bool turning = false; //becomes true when boid reaches the end of the "tank"

    public float topbound_velocity = 20;
    public float lowbound_velocity = 5;
    public float chances_to_ApplyRule = 2;

    void Start ()
    {
        // makes the fish all start moving at different speeds
        //speed of which each individual boid moves (thrusts)
        speed = Random.Range(lowbound_velocity, topbound_velocity);
	}
	
	void Update () {
                                                            //(>= globalFlock.tankSize)
        if (Vector3.Distance(transform.position, Vector3.zero) >= 20) //testing boid position and center of world
        {
            turning = true; //gone outside
        }
        else
        {
            turning = false;
        }

        //alignment turns the object towards the Average Heading direction of the group
        if(turning) //calculate to move boid back towards the same direction (turning = true)
        {
            //speed rotated = average speed direction*
            Vector3 direction = Vector3.zero - transform.position;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
            speed = Random.Range(lowbound_velocity, topbound_velocity); //0.5f,1 - speed of which each individual boid moves
        }


        else //turning = false
        {
            //Runs ApplyRules() 1 in 5 times - flocking too much, then increase 5 value
            if (Random.Range(0, chances_to_ApplyRule) < 1)
            {
                ApplyRules();
            }
        }
        transform.Translate(0, 0, Time.deltaTime * speed); //translate/move if we are turning
	}

      void ApplyRules()
      {
        GameObject[] gos; //array containing game object boids
        //List<GameObject> gos;
        gos = globalFlock.allBoid;

        Vector3 vcentre = Vector3.zero; //calculate center of the group
        Vector3 vavoid = Vector3.zero; //calculate avoidance - avoid hitting any boid near it - points away any particular neighbours
        float gSpeed = 0.1f; //group speed

        Vector3 goalPos = globalFlock.goalPos;

        float dist;

        //SEPARATION avoids the other birds
        int groupSize = 0; //based on who is within the distance
        foreach (GameObject go in gos)
        {
            if(go != this.gameObject)
            {
                dist = Vector3.Distance(go.transform.position, this.transform.position);
                if(dist <= neighbourDistance) //if boid is within the distance of flocking
                {
                    vcentre += go.transform.position; //add up all the centers in the group
                    groupSize++;

                    if(dist < 1.0f) //avoid if it gets into a very small distance (less than 1 away, we are about to collide)
                    {
                        vavoid = vavoid + (this.transform.position - go.transform.position); //calculate vector in the other direction
                    }

                    flock anotherFlock = go.GetComponent<flock>(); //grab the flock script attatched to the neighbouring boids
                    gSpeed = gSpeed + anotherFlock.speed; //add the speed of neighbouring boid to the total GROUP speed (to create average of group)
                    
                }

            }

        }

        //COHESION fly towards the center of the flock
        if (groupSize > 0) //if boid is in a group
        {
            vcentre = vcentre / groupSize + (goalPos - this.transform.position); //calculate average center of group
            speed = gSpeed / groupSize; //avg group speed

            //subtract mean position with self position
            Vector3 direction = (vcentre + vavoid) - transform.position; //gives the direction we need to turn into
            if(direction != Vector3.zero) //fish is going to change directions
            {
                //always point in the direction of the flocks
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime); //Slerp slowly turns to the Look Direction without snapping
            }
        }

      }
}
