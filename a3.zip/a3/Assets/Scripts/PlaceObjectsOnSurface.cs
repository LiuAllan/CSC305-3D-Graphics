﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceObjectsOnSurface : MonoBehaviour {

    public GameObject[] objectsToSpawn; //list of objects in array to spawn
    public float spawnRadius = 10.0f;
    public int numberOfObjects = 10;
    public bool orientToSurface = false;

	void Start () {
		for(int i = 0; i < numberOfObjects; i++)
        {
            //what we will spawn
            GameObject objectToSpawn = objectsToSpawn[Random.Range(0, objectsToSpawn.Length)]; //randomly pick an object to spawn in array
            Vector2 spawnPositionV2 = Random.insideUnitCircle * spawnRadius; //randomly pick spawn location within the radius declared
            Vector3 spawnPosition = new Vector3 (spawnPositionV2.x, 0.0f, spawnPositionV2.y); //spawn location on grid
            Vector3 transformOffsetSpawnPosition = transform.position + spawnPosition;

            RaycastHit hit;
            if (Physics.Raycast(transformOffsetSpawnPosition, Vector3.down, out hit)) //ray cast downward until it hits the surface, if not do not spawn object
            {
                Vector3 finalSpawnPosition = hit.point;
                Quaternion orientation;

                if (orientToSurface)
                {
                    orientation = Quaternion.LookRotation(hit.normal); //orientate object normal to surface
                }
                else //orientToSurface is not ticked
                {
                    orientation = objectToSpawn.transform.rotation;
                }
                Instantiate(objectToSpawn, finalSpawnPosition, orientation); // create an object for the instance
            }
        }
	}
	
	// Update is called once per frame
	//void Update () {
		
	//}
}
