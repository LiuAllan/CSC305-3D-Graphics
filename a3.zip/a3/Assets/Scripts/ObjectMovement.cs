﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMovement : MonoBehaviour {

    [Range(0.001f, 1)]
    public float Speed = 0.01f;
    private float current_t;
    private CatmullRomSpline3D spline;

    ////boid variables
    //public int spawnCount = 50;

    //public static int tankSize = 3; //radius
    //public static Vector3 goalPos = Vector3.zero;


    ////make a list for flock of birds
    //public static List<GameObject> object_list; //list of clones (was private)
    //public GameObject object_prefab; //prefab for the child to be instantiated
    //public GameObject head_boid_prefab;
    //GameObject newObject; //one clone object

    void Start () {
        spline = new CatmullRomSpline3D();
        Vector3[] cps = new Vector3[6]; //the array for 6 positions - the more spots initialized = the more smooth the object will move
        cps[0] = new Vector3(-10, 18, -10);
        cps[1] = new Vector3(0, 15, 10);
        cps[2] = new Vector3(10, 18, -10);
        cps[3] = cps[0];
        cps[4] = cps[1];
        cps[5] = cps[2];
        spline.control_points = cps;
        current_t = 0;

        gameObject.transform.Rotate(270, 90, 0);

        ////make clones that are based on the parent object. Clone's orgin points to the parent in the world
        //object_list = new List<GameObject>();
        //for (int i = 0; i < spawnCount; i++)
        //{
        //    //randomly spawn in the position of clones
        //    Vector3 pos = new Vector3(Random.Range(-Size, Size),
        //                              Random.Range(-Size, Size),
        //                              Random.Range(-Size, Size));

        //    //GameObject newObject = new GameObject();
        //    newObject = (GameObject)Instantiate(object_prefab, pos, Quaternion.identity);
        //    newObject.transform.parent = gameObject.transform; //parent == red boid. Manipulate position based on parent
        //    newObject.name = "Boid number " + i.ToString();
        //    object_list.Add(newObject);

        //    //TODO - animation of the small boids
        //    //1. separation 2.alignment(radius of circle) 3.cohesion 4.follow goal

        //}
    }

    void Update () {
        current_t += Speed; //current time add the current Speed
        if (current_t > 3) current_t = current_t - 3; //value 3 need to change

        Vector3 curr_pos = EvaluateAt(current_t);
        Vector3 next_pos = EvaluateAt(current_t + Speed);

        gameObject.transform.position = curr_pos; //transform the position - without this, object will rotate at the same spot

        Vector3 forward = next_pos - curr_pos;

        if(forward.sqrMagnitude > 1e-5)
        {
            forward.Normalize();
            gameObject.transform.forward = forward;
        }

        ////update the flock
        //if (Random.Range(0, 10000)<50)
        //{
        //    goalPos = new Vector3(Random.Range(-tankSize, tankSize),
        //                                  Random.Range(-tankSize, tankSize),
        //                                  Random.Range(-tankSize, tankSize));
        //    head_boid_prefab.transform.position = goalPos;
        //}
    }

    Vector3 EvaluateAt(float t)
    {
        if (t > 3) t -= 3;
        return spline.Sample(t);
    }

    

}
