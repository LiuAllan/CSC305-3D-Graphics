﻿using System.Collections;
using UnityEngine;

class Tile
{
    public GameObject theTile; //each of the planes are place in a Tile
    public float creationTime; //keeps track of creation time

    //constructor links the actual game object in the instance and creation time
    public Tile(GameObject t, float ct)
    {
        theTile = t;
        creationTime = ct;

    }

}


public class GenerateInfinite : MonoBehaviour
{
    // positioning of the perlin noise function needs to meet at the ends to generate a continuous mesh by connecting several planes.
    public GameObject plane; //prefab of the generated plane
    public GameObject player; //location of the camera

    int planeSize = 10; //each plane is 10x10 - to know where to place next tile, 10 away from the previous one
    int halfTilesX = 5; //how many tiles are "around" the player in any direction
    int halfTilesZ = 5;

    //keep track where player is, and was - so we don't keep generating terrain every update
    Vector3 startPos;

    //holds onto the gameobjects and index them based on a name
    Hashtable tiles = new Hashtable();

    void Start()
    {

        this.gameObject.transform.position = Vector3.zero;
        startPos = Vector3.zero;

        float updateTime = Time.realtimeSinceStartup;

        //loops to make 2D ground plane
        for (int x = -halfTilesX; x < halfTilesX; x++)
        {
            for (int z = -halfTilesZ; z < halfTilesZ; z++)
            {
                Vector3 pos = new Vector3((x * planeSize + startPos.x), 0, (z * planeSize + startPos.z));
                GameObject t = (GameObject)Instantiate(plane, pos, Quaternion.identity); //create the tile for the instance

                // give the Tile a name based on the x and z position
                string tilename = "Tile_" + ((int)(pos.x)).ToString() + "_" + ((int)(pos.z)).ToString();
                    t.name = tilename;

                //sets the tile game object, the time it was created
                Tile tile = new Tile(t, updateTime);
                tiles.Add(tilename, tile); //add the tile to the hash table

            }

        }
    }

    void Update()
    {
        //determine how far the player has moved since the last terrain update
        int xMove = (int)(player.transform.position.x - startPos.x); // calculate difference between where player was and current
        int zMove = (int)(player.transform.position.z - startPos.z);

        //if we move more distance than the plane size, generate more tiles
        if(Mathf.Abs(xMove) >= planeSize || Mathf.Abs(zMove) >= planeSize)
        {
            float updateTime = Time.realtimeSinceStartup; //used to delete all the tiles that has been existed the longest

            //force an integer position for the player location and round down to nearest tilesize. Can't generate on a float
            int playerX = (int)(Mathf.Floor(player.transform.position.x / planeSize) * planeSize);
            int playerZ = (int)(Mathf.Floor(player.transform.position.z / planeSize) * planeSize);

            //similar to above loop, but instead of positioning around (0,0,0), we position tiles around the player
            for(int x = -halfTilesX; x < halfTilesX; x++)
            {
                for(int z = -halfTilesZ; z < halfTilesZ; z++)
                {
                    Vector3 pos = new Vector3((x * planeSize + playerX), 0, (z * planeSize + playerZ));
                    string tilename = "Tile_" + ((int)(pos.x)).ToString() + "_" + ((int)(pos.z)).ToString();
                    
                    //create the tiles only if the do NOT already exist
                    if(!tiles.ContainsKey(tilename))
                    {
                        GameObject t = (GameObject)Instantiate(plane, pos, Quaternion.identity);
                        t.name = tilename;
                        Tile tile = new Tile(t, updateTime);
                        tiles.Add(tilename, tile);
                    }
                    else //tile does exist in the array, update time
                    {
                        (tiles[tilename] as Tile).creationTime = updateTime;
                    }
                }
            }

            //remove all tiles that is not just recently created or with time updated
            //put new tiles and to-be kept tiles in hash table
            Hashtable newTerrain = new Hashtable();
            foreach(Tile tls in tiles.Values)
            {
                if(tls.creationTime != updateTime) //delete old tiles in working hash table
                {
                    Destroy(tls.theTile);
                }
                else //hash table will only contain the new tiles
                {
                    newTerrain.Add(tls.theTile.name, tls);
                }
            }

            //copy the new values into the working hash table
            //re-indexes the values to prevent "tombstone" and unefficiency
            tiles = newTerrain;

            //set the start position to the current position
            startPos = player.transform.position;

        }
    }
}
