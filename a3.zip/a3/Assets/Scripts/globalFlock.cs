﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class globalFlock : MonoBehaviour {

    //boid variables
    static int spawnCount = 50;
    public static int radius = 5; //radius 5 - the area where the flocks can go
    public static Vector3 goalPos = Vector3.zero; //set goal position initially set at center of the world

    //make a list for flock of birds
    public static GameObject[] allBoid = new GameObject[spawnCount];

    //public static List<GameObject> object_list; //list of clones (was private)
    public GameObject object_prefab; //prefab for the child to be instantiated
    public GameObject head_boid_prefab;
    //GameObject newObject; //one clone object

    void Start()
    {
        for(int i = 0; i < spawnCount; i++)
        {
            //create position of the fish in 3D space, using a random value.
            Vector3 pos = new Vector3(Random.Range(-radius, radius), //generate a range around the ORIGIN of the world
                                      Random.Range(-radius, radius),
                                      Random.Range(-radius, radius));
            allBoid[i] = (GameObject)Instantiate(object_prefab, pos, Quaternion.identity);
            //allBoid[i].transform.parent = gameObject.transform;// ***follow the parent
        }
    }
	
    //Move towards the head_boid
	void Update () {
        goalPos = new Vector3(gameObject.transform.position.x,
                              gameObject.transform.position.y,
                              gameObject.transform.position.z);
        head_boid_prefab.transform.position = goalPos;
        //goalPos = new Vector3(head_boid_prefab.transform.position.x, head_boid_prefab.transform.position.y, head_boid_prefab.transform.position.z);
    }
}
