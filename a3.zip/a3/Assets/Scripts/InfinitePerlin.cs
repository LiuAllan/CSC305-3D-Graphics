﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfinitePerlin : MonoBehaviour {

    int heightScale = 10;
    float detailScale = 9.0f;

    // Use this for initialization
    void Start()
    {
        Mesh mesh = this.GetComponent<MeshFilter>().mesh;
        Vector3[] vertices = mesh.vertices;
        for (int v = 0; v < vertices.Length; v++)
        {
            vertices[v].y = Mathf.PerlinNoise((vertices[v].x + this.transform.position.x) / detailScale,
            (vertices[v].z + this.transform.position.z) / detailScale) * heightScale;
        }

        mesh.vertices = vertices;
        mesh.RecalculateBounds();
        mesh.RecalculateNormals();
        //this.gameObject.AddComponent<MeshCollider>();
        MeshCollider meshc = this.gameObject.AddComponent(typeof(MeshCollider)) as MeshCollider; //mapping Mesh Collider that takes the shape of the Mesh render instead of the plane
        meshc.sharedMesh = mesh;
    }

    // Update is called once per frame
    void Update()
    {

    }


}
