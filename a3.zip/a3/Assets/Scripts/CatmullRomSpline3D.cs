﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CatmullRomSpline3D {

    private Vector3[] cps; //control point
    private Vector3[] tangents; //tangent for every point
    private float parametric_range; //time for the boid to travel in a direction

    private Vector4 h_func(float t)
    {
        //based on the spline equation
        float t2 = t * t;
        float t3 = t2 * t;
        float hx = 2 * t3 - 3 * t2 + 1;
        float hy = t3 - 2 * t2 + t;
        float hz = -2 * t3 + 3 * t2;
        float hw = t3 - t2;

        return new Vector4(hx, hy, hz, hw);
    }

    //lecture slide 11
    public Vector3[] control_points
    {
        set
        {
            cps = value;                                                    //define indexs for every control point - because its possible to get NULL
            parametric_range = cps.Length - 3;                                              // 3 will varies depending on the parameter of the terrain
            tangents = new Vector3[cps.Length - 2];
            for(int i = 0; i < tangents.Length; ++i)
            {
                tangents[i] = (cps[i + 2] - cps[i]) / 2.0f;                                             //will change (2)
            }
        }
    }

    //check the travel time, then change direction depending on the set time t
    public Vector3 Sample(float t)
    {
        //do not allow the boid to go out beyond a certain time
        if(t > 0 && t < parametric_range)
        {
            int knot_prev = Mathf.FloorToInt(t);
            float local_param = t - (float)(knot_prev); //local param = local parameter at every point
            Vector4 h = h_func(local_param); //handle function

            //control points for the formula
            //Unit interval (0,1) polynomial
            Vector3 p0 = cps[knot_prev + 1];
            Vector3 m0 = tangents[knot_prev];
            Vector3 p1 = cps[knot_prev + 2];
            Vector3 m1 = tangents[knot_prev + 1];
            return h.x * p0 + h.y * m0 + h.z * p1 + h.w * m1; //return function p(t) - on wiki
        }
        else
        {
            return Vector3.zero;
        }
    }

}
