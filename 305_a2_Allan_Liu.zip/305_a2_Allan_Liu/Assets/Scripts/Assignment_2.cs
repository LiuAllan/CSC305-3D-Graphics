﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Assignment_2 : MonoBehaviour
{
    public Material simpleMaterial;

    // This is a demonstration of generate a slice of 2D perlin noise on a 1D line
    // Note that if we completely operate in 1D, the method can be simplified to exclude
    // the 2D vector gradient and dot products
    void Start()
    {
        MeshRenderer renderer = gameObject.GetComponent<MeshRenderer>();
        renderer.material = simpleMaterial;
        GenerateSurface();



    //float[] height = Perlin2DNoise(250, 5, 10); // height = Vector2

    //    LineRenderer line_render = gameObject.GetComponent<LineRenderer>();
    //    line_render.positionCount = 250;
    //    Vector3[] line = new Vector3[250];
    //    float x_step = 0.1f;
    //    float half_offset = 250.0f * x_step / 2.0f;
    //    for (int i = 0; i < 250; ++i)
    //    {
    //        line[i] = new Vector3(x_step * i - half_offset, height[i], 0);
    //    }
    //    line_render.SetPositions(line);
    }

    void Update()
    {

    }

    void GenerateSurface()
    {
        Mesh mesh = gameObject.GetComponent<MeshFilter>().mesh;
        Vector3[] vertices = mesh.vertices;
        int[] indices = mesh.triangles;
        Vector2[] uvs = mesh.uv;

        mesh.Clear();

        //subdivision = how many squares per row/col
        int subdivision = 250;
        int stride = subdivision + 1;
        int num_vert = stride * stride;
        int num_tri = subdivision * subdivision * 2;

        indices = new int[num_tri * 3];
        int index_ptr = 0;
        for (int i = 0; i < subdivision; i++)
        {
            for (int j = 0; j < subdivision; j++)
            {
                int quad_corner = i * stride + j;
                indices[index_ptr] = quad_corner;
                indices[index_ptr + 1] = quad_corner + stride;
                indices[index_ptr + 2] = quad_corner + stride + 1;
                indices[index_ptr + 3] = quad_corner;
                indices[index_ptr + 4] = quad_corner + stride + 1;
                indices[index_ptr + 5] = quad_corner + 1;
                index_ptr += 6;
            }
        }

        Debug.Assert(index_ptr == indices.Length);

        const float xz_start = -5;
        const float xz_end = 5;
        float step = (xz_end - xz_start) / (float)(subdivision);
        vertices = new Vector3[num_vert];
        uvs = new Vector2[num_vert];

        for (int i = 0; i < stride; i++)
        {
            for (int j = 0; j < stride; j++)
            {
                // notice the bahavior here
                bool show_backface = false;
                float cur_x;
                float cur_z;
                //i don't know how this happened(showing back faces)
                if (show_backface)
                {
                    cur_x = xz_start + i * step;
                    cur_z = xz_start + j * step;
                }
                else
                {
                    cur_x = xz_start + j * step;
                    cur_z = xz_start + i * step;
                }
                float cur_y = (-(cur_x * cur_x + cur_z * cur_z) / (float)10.0) + 5;
                vertices[i * stride + j] = new Vector3(cur_x, cur_y, cur_z);
            }
        }

        mesh.vertices = vertices;
        mesh.uv = uvs;
        mesh.triangles = indices;
        mesh.RecalculateNormals();



    }



    //f(t) = 6t^5-15t^4+10t^3
    float interpolation_function(float t)
    {
        float t_cubic = t * t * t;
        float t_square = t * t;

        return 6 * t_cubic * t_square - 15 * t_square * t_square + 10 * t_cubic;
    }

    float[] Perlin2DNoise(int num_sample, float max_value, int frequency)
    {
        Vector2[] gradients = new Vector2[frequency + 1];
        //method 1. initialize random gradients with random numbers

        //for (int i = 0; i < frequency + 1; ++i)
        //{
        //    Vector2 rand_vector = new Vector2(Random.value * 2 - 1, Random.value * 2 - 1);
        //    gradients[i] = rand_vector.normalized;
        //}

        //method 2. random pick from the 4 edge centers

        Vector2[] edge_centers = new Vector2[4];
        edge_centers[0] = (new Vector2(0, 1)).normalized;
        edge_centers[1] = (new Vector2(0, -1)).normalized;
        edge_centers[2] = (new Vector2(1, 0)).normalized;
        edge_centers[3] = (new Vector2(-1, 0)).normalized;

        for (int i = 0; i < frequency + 1; ++i)
        {
            float roll = Random.value;
            if (roll < 0.25f) gradients[i] = edge_centers[0];
            else if (roll < 0.5f) gradients[i] = edge_centers[1];
            else if (roll < 0.75f) gradients[i] = edge_centers[2];
            else gradients[i] = edge_centers[3];
        }

        //generate two (instead of 4) dot products and blend them together
        float[] noise = new float[num_sample];
        float period = 1.0f / frequency;
        float step = 1.0f / num_sample;
        for (int i = 0; i < num_sample; ++i)
        {
            float location_period = step * i / period;
            int cell = Mathf.FloorToInt(location_period);
            float in_cell_location = location_period - cell;
            float dot_prev = Vector2.Dot(gradients[cell], new Vector2(in_cell_location, 0));
            float dot_next = Vector2.Dot(gradients[cell + 1], new Vector2(in_cell_location - 1, 0));
            float weight = interpolation_function(in_cell_location);
            noise[i] = (1 - weight) * dot_prev + weight * dot_next;
        }

        return noise;
    }

}
